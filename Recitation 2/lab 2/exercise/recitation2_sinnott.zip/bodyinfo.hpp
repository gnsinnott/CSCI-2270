#ifndef BMI_HPP
#define BMI_HPP

#include <iostream>

using namespace std;

/*TODO 1: Create a struct "BodyInfo" with height and weight
* ...
*/
struct BodyInfo {
    double weight;
    double height;
};

#endif